from django import forms
import datetime

class SearchForm(forms.Form):
    searched_car = forms.CharField(label='차를 검색하세요', max_length=10)
    time_in = forms.DateTimeField(widget=forms.TextInput(attrs={'class:datepicker'}))

class SpecialSearch(forms.Form):
    searched_car = forms.CharField(label='차를 검색하세요', max_length=10)
    time_in = forms.DateTimeField(label='날짜를 검색하세요')