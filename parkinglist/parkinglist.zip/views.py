from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect, Http404
from .models import Currparkinglot, Parkinglot
from .forms import SearchForm

def index(request):
    existing_cars = Currparkinglot.objects.all()
    car2darray = [[False for i in range(10)] for j in range(10)]
    for car in existing_cars:
        if car.sectionno == '':
            continue
        else:
            # y = alphabet                  - A
            # x = number following alphabet - 10
            y = ord(car.sectionno[0]) - 65
            x = int((car.sectionno).replace(car.sectionno[0], '')) - 1
            car2darray[x][y] = True
    context = {
        'title': '주차장 현황',
        'car2darray': car2darray
    }
    return render(request, 'parkinglist/index.html', context)

def detail(request, carno):
    try:
        car = Parkinglot.objects.filter(carno=carno)
    except Parkinglot.objects.filter(carno=carno).DoesNotExist:
        raise Http404("Car does not exist")
    return render(request, 'parkinglist/detail.html', {'car' : car})

def get_search(request):
    if request.method == 'POST':
        form = SearchForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data.get('searched_car')
            car = Parkinglot.objects.filter(carno=data)
            return render(request, 'parkinglist/detail.html', {'car' : car})
    else:
        form = SearchForm()
        return render(request, 'parkinglist/search.html', {'form' : form})
